import React, { Component } from "react";

export default class NotFound extends Component {
    constructor(props) {
        super(props);
    }

    render () {
        return <p>The page cannot be found.</p>;
    }
}